## Data Overview

The sample folder consists of 2 main data files:
- `5k_article_activity.csv`
- `5k_articles.csv`

#### 5k_articles.csv
Here you will find main information on articles content. Columns in `5k_articles.csv` are:

- `article_id` - unique article indentifier
- `title` - articles title
- `topic_desc` - articles topic description/name
- `article_publish_date` - date when article was published on mondaq.com
- `country_desc` - articles country description/name (i.e. which country does the article cover)

#### 5k_article_activity.csv
Here you will find information on articles activity (i.e. when the articles were clicked on). Columns in `5k_article_activity.csv` are:

- `article_id` - unique article identifier
- `session_tracking_id` -  unique event identifier
- `individual_session_id` - unique session identifier (i.e. there can be multiple unique events in a single session)
- `click_event_date` - date when article was interacted with (i.e. clicked on) 

Please note that `5k_article_activity.csv` contains activity data only on the first 2 weeks since articles publishing date.
